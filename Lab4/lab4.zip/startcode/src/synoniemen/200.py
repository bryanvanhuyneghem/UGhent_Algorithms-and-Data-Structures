def synoniemen():
synoniem = input()
tekst = input()
synoniem = {
    'straf': 'sanctie',
    'stout': 'kwaadaardig',
    'leerling': 'cursist',
    'leraar': 'docent',
    'school': 'troep',
    'knoeien': 'broddelen',
    'kwaad': 'gebelgd',
    'slecht': 'beroerd'
}

    print(synoniemen)