def overzicht(codes):
    landcode1="01"
    tel1=0
    tup1=tuple("Engelstalige landen:",tel1)
    
    landcode2="2"
    tel2=0
    tup2=tuple("Franstalige landen:",tel2)
    
    landcode3="3"
    tel3=0
    tup3=tuple("Duitstalige landen:",tel3)
    
    landcode4="4"
    tel4=0
    tup4=tuple("Japan:",tel4)
    
    landcode5="5"
    tel5=0
    tup5=tuple("Russischtalige landen:",tel5)
    
    landcode6="7"
    tel6=0
    tup6=tuple("China:",tel6)
    
    landcode7="689"
    tel7=0
    tup7=tuple("Overige landen:",tel7)
    
    