def verlaat_ploeg(naam, groep, groepen):
    groepen[groep].remove[naam]
    if groepen == []:
        del groepen[groep]
