def verlaat_ploeg (player,ploeg,data):
    data[ploeg].remove(player)
    if data[ploeg] = (''):
        remove.data[ploeg]
    return data
def voervoeg_ploeg
    