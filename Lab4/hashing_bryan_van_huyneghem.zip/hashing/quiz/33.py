def verlaat_ploeg(persoon, ploeg, data):
    data[ploeg].remove(persoon)
    
    return(data)
