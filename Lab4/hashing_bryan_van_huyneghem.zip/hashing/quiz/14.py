def verlaat_ploeg(naam, ploeg, woordenboek):
    woordenboek[ploeg] -= naam
    return woordenboek
    